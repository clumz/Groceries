// Plate — Browse / Discover
function BrowseScreen({ onNav, active }) {
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState('all');

  const cats = [
    { k: 'all', l: 'All', e: '✨' },
    { k: 'protein', l: 'High protein', e: '💪' },
    { k: 'quick', l: '< 20 min', e: '⚡' },
    { k: 'veg', l: 'Vegetarian', e: '🌱' },
    { k: 'budget', l: 'Budget', e: '💰' },
    { k: 'gf', l: 'GF', e: '🌾' },
  ];

  const recipes = [
    { name: 'Lemon herb chicken bowl', cuisine: 'Mediterranean', t: 20, k: 520, p: 42, img: PLATE_IMG.bowl, tag: 'High protein', tagColor: 'lime' },
    { name: 'Coconut chickpea curry', cuisine: 'Indian', t: 25, k: 480, p: 22, img: PLATE_IMG.curry, tag: 'Vegan', tagColor: 'butter' },
    { name: 'Charred halloumi salad', cuisine: 'Greek', t: 15, k: 410, p: 28, img: PLATE_IMG.greek, tag: 'GF', tagColor: 'sky' },
    { name: 'Crispy tofu pad thai', cuisine: 'Thai', t: 22, k: 560, p: 26, img: PLATE_IMG.thai, tag: 'Veg', tagColor: 'lime' },
    { name: 'Smoky bean tacos', cuisine: 'Mexican', t: 18, k: 480, p: 20, img: PLATE_IMG.taco, tag: '$1.80/serv', tagColor: 'butter' },
    { name: 'Steak salad with chimichurri', cuisine: 'Modern Aus', t: 22, k: 620, p: 48, img: PLATE_IMG.steak, tag: 'High protein', tagColor: 'coral' },
  ];

  return (
    <div className="plate-screen" style={{ paddingBottom: 110 }}>
      <TopBar
        eyebrow="222 recipes · personalised"
        title={<span>Find <span style={{ fontStyle: 'italic', fontWeight: 500 }}>tonight's</span> dinner</span>}
      />

      {/* Search */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div style={{ position: 'relative' }}>
          <div style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--plate-ink-3)' }}>
            <Icon.browse size={16}/>
          </div>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="What are you craving?"
            style={{
              width: '100%', height: 48, paddingLeft: 40, paddingRight: 50,
              borderRadius: 999, border: '1.5px solid var(--plate-ink)',
              background: 'var(--plate-surface)', fontSize: 14, fontFamily: 'var(--font-body)',
              outline: 'none', boxShadow: '2px 2px 0 var(--plate-ink)',
            }}
          />
          <button style={{
            position: 'absolute', right: 6, top: 6, width: 36, height: 36,
            borderRadius: 999, border: 'none', background: 'var(--plate-ink)',
            color: 'var(--plate-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Icon.filter size={14}/></button>
        </div>
      </div>

      {/* Categories */}
      <div className="row-scroll" style={{ padding: '0 20px 18px 20px' }}>
        {cats.map(c => (
          <div key={c.k} className={`chip ${cat === c.k ? 'on lime' : ''}`} onClick={() => setCat(c.k)}>
            <span>{c.e}</span><span>{c.l}</span>
          </div>
        ))}
      </div>

      {/* Featured spotlight */}
      <div style={{ padding: '0 20px 18px 20px' }}>
        <div className="card" style={{ padding: 0, overflow: 'hidden', background: 'var(--plate-coral)', borderRadius: 26, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'stretch', minHeight: 160 }}>
            <div style={{ flex: 1, padding: '18px 16px 18px 18px', color: '#fff' }}>
              <span className="sticker butter" style={{ fontSize: 10, padding: '3px 8px' }}>Editor's pick</span>
              <div className="display" style={{ fontSize: 22, marginTop: 10, color: '#fff' }}>
                One-pan harissa<br/><span style={{ fontStyle: 'italic', fontWeight: 500 }}>roast veg</span>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 12, alignItems: 'center', fontSize: 12, opacity: 0.95, fontFamily: 'var(--font-display)', fontWeight: 600 }} className="tabular">
                <span>22 min</span>•<span>410 kcal</span>•<span>$3.20/serv</span>
              </div>
            </div>
            <div style={{ width: 130, position: 'relative' }}>
              <img src={PLATE_IMG.curry} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}/>
            </div>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div style={{ padding: '0 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {recipes.map(r => (
          <BrowseCard key={r.name} {...r}/>
        ))}
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

function BrowseCard({ name, cuisine, t, k, p, img, tag, tagColor }) {
  return (
    <div className="card" style={{ padding: 0, borderRadius: 20, overflow: 'hidden', boxShadow: '2px 2px 0 var(--plate-ink)' }}>
      <div style={{ position: 'relative', height: 110 }}>
        <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderBottom: '1.5px solid var(--plate-ink)' }}/>
        {tag && <span className={`sticker ${tagColor}`} style={{
          position: 'absolute', top: 8, left: 8, fontSize: 10, padding: '3px 8px',
          boxShadow: '1.5px 1.5px 0 var(--plate-ink)',
        }}>{tag}</span>}
      </div>
      <div style={{ padding: 12 }}>
        <div className="eyebrow" style={{ marginBottom: 4 }}>{cuisine}</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, lineHeight: 1.2, height: 32, overflow: 'hidden' }}>{name}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 8, alignItems: 'center' }}>
          <span className="small tabular" style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}><Icon.clock size={10}/>{t}m</span>
          <span style={{ width: 2, height: 2, background: 'var(--plate-ink-3)', borderRadius: 999 }}/>
          <span className="small tabular">{k}<span style={{ fontSize: 9, color: 'var(--plate-ink-3)' }}>kcal</span></span>
          <span className="small tabular" style={{ marginLeft: 'auto', color: 'var(--plate-coral)', fontWeight: 600 }}>{p}gP</span>
        </div>
      </div>
    </div>
  );
}

window.BrowseScreen = BrowseScreen;
