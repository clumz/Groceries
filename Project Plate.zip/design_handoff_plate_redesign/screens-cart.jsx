// Plate — Cart screen
function CartScreen({ onNav, active }) {
  const [store, setStore] = useState('woolies');
  const sections = [
    { name: 'Produce', items: [
      { n: 'Broccolini', q: '2 bunches', p: 4.50, sub: false },
      { n: 'Snow peas', q: '300g', p: 5.20, sub: false },
      { n: 'Spinach', q: '1 bag', p: 3.80, sub: true },
      { n: 'Lemons', q: '4', p: 2.40, sub: false },
    ]},
    { name: 'Protein', items: [
      { n: 'Salmon fillets', q: '4 × 180g', p: 32.00, sub: false },
      { n: 'Free-range chicken thigh', q: '600g', p: 14.20, sub: false },
      { n: 'Firm tofu', q: '400g', p: 4.80, sub: false },
    ]},
    { name: 'Pantry', items: [
      { n: 'Jasmine rice', q: '1kg', p: 6.50, sub: false },
      { n: 'White miso paste', q: '250g', p: 8.90, sub: true },
      { n: 'Coconut milk', q: '400ml × 2', p: 5.40, sub: false },
    ]},
  ];

  const total = sections.reduce((s, sec) => s + sec.items.reduce((a, b) => a + b.p, 0), 0);

  return (
    <div className="plate-screen" style={{ paddingBottom: 200 }}>
      <TopBar
        eyebrow="14 meals · 4 servings each"
        title="Weekly cart"
      />

      {/* Store toggle */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div style={{ display: 'flex', padding: 4, background: 'var(--plate-surface)', border: '1.5px solid var(--plate-ink)', borderRadius: 999 }}>
          {[{ k: 'woolies', l: 'Woolworths', sub: '$184 · today 5pm' }, { k: 'coles', l: 'Coles', sub: '$192 · tmrw 9am' }].map(s => (
            <div key={s.k} onClick={() => setStore(s.k)} style={{
              flex: 1, padding: '8px 12px', borderRadius: 999, cursor: 'pointer', textAlign: 'center',
              background: store === s.k ? 'var(--plate-ink)' : 'transparent',
              color: store === s.k ? 'var(--plate-bg)' : 'var(--plate-ink)',
            }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>{s.l}</div>
              <div className="tabular" style={{ fontSize: 10, opacity: 0.7, marginTop: 1 }}>{s.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Substitution banner */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div style={{
          padding: '12px 14px', borderRadius: 18, background: 'var(--plate-butter)',
          border: '1.5px solid var(--plate-ink)', display: 'flex', alignItems: 'center', gap: 10,
          boxShadow: '2px 2px 0 var(--plate-ink)',
        }}>
          <Icon.sparkle size={16}/>
          <div style={{ flex: 1, fontSize: 13, lineHeight: 1.3 }}>
            <strong style={{ fontFamily: 'var(--font-display)' }}>2 smart subs</strong> save <span className="tabular">$4.10</span> this week
          </div>
          <button className="btn sm" style={{ height: 30, fontSize: 11, boxShadow: 'none', background: 'var(--plate-ink)', color: 'var(--plate-bg)' }}>Review</button>
        </div>
      </div>

      {/* Sections */}
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {sections.map(sec => (
          <div key={sec.name}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8, padding: '0 4px' }}>
              <span className="eyebrow">{sec.name}</span>
              <span className="small tabular">{sec.items.length} items</span>
            </div>
            <div className="card flat" style={{ padding: 0, borderRadius: 18 }}>
              {sec.items.map((i, idx) => (
                <div key={i.n} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderBottom: idx === sec.items.length-1 ? 'none' : '1px solid var(--plate-line)' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--plate-bg)', border: '1px solid var(--plate-line)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
                    {sec.name === 'Produce' ? '🥬' : sec.name === 'Protein' ? '🐟' : '🍚'}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>{i.n}</span>
                      {i.sub && <span className="sticker butter" style={{ fontSize: 9, padding: '1px 6px', boxShadow: '1px 1px 0 var(--plate-ink)' }}>sub</span>}
                    </div>
                    <div className="small tabular">{i.q}</div>
                  </div>
                  <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>${i.p.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom pinned total */}
      <div style={{ position: 'fixed', bottom: 96, left: '50%', transform: 'translateX(-50%)', width: 374, zIndex: 4 }}>
        <div className="card" style={{ padding: 14, borderRadius: 22, background: 'var(--plate-ink)', borderColor: 'var(--plate-ink)', color: 'var(--plate-bg)' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
            <div>
              <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.55)' }}>Total · 28 items</div>
              <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 28 }}>${total.toFixed(2)}</div>
            </div>
            <span className="sticker lime" style={{ boxShadow: '2px 2px 0 var(--plate-bg)' }}>$184/250 budget</span>
          </div>
          <button className="btn lime" style={{ width: '100%', boxShadow: 'none' }}>
            Checkout with Woolworths <Icon.arrow size={14}/>
          </button>
        </div>
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

window.CartScreen = CartScreen;
