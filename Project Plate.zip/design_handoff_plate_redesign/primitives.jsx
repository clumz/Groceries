// Plate — shared UI primitives
const { useState, useMemo } = React;

// Macros ring with progress
function MacrosRing({ size = 180, kcal = 1640, target = 2100, p = 92, c = 180, f = 58, pTarget = 130, cTarget = 220, fTarget = 70 }) {
  const r = size / 2 - 14;
  const cx = size / 2;
  const cy = size / 2;
  const circ = 2 * Math.PI * r;
  const pct = Math.min(kcal / target, 1);
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={cx} cy={cy} r={r} className="ring-track" />
        <circle
          cx={cx} cy={cy} r={r}
          className="ring-prog"
          stroke="var(--plate-coral)"
          strokeDasharray={`${circ * pct} ${circ}`}
          transform={`rotate(-90 ${cx} ${cy})`}
        />
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex',
        flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 2,
      }}>
        <div className="eyebrow" style={{ color: 'var(--plate-ink-3)' }}>kcal today</div>
        <div className="display tabular" style={{ fontSize: 38 }}>{kcal.toLocaleString()}</div>
        <div className="small tabular">of {target.toLocaleString()}</div>
      </div>
    </div>
  );
}

function MacroBar({ label, val, target, color }) {
  const pct = Math.min(val / target, 1) * 100;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <span className="eyebrow">{label}</span>
        <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13 }}>
          {val}<span style={{ color: 'var(--plate-ink-3)', fontWeight: 400 }}>/{target}g</span>
        </span>
      </div>
      <div className="macro-bar"><span style={{ width: `${pct}%`, background: color }} /></div>
    </div>
  );
}

// Food image with sticker tag
function FoodImage({ src, alt, h = 140, tag, tagColor = 'lime', tagPos = { top: 10, right: 10 } }) {
  return (
    <div style={{ position: 'relative', height: h, borderRadius: 18, overflow: 'hidden', border: '1.5px solid var(--plate-ink)' }}>
      <img src={src} alt={alt} style={{ width: '100%', height: '100%', objectFit: 'cover' }} loading="lazy" />
      {tag && (
        <span className={`tag-sticker`} style={{
          ...tagPos,
          background: tagColor === 'lime' ? 'var(--plate-lime)' : tagColor === 'coral' ? 'var(--plate-coral)' : tagColor === 'butter' ? 'var(--plate-butter)' : 'var(--plate-surface)',
          color: tagColor === 'coral' ? '#fff' : 'var(--plate-ink)',
        }}>{tag}</span>
      )}
    </div>
  );
}

// Tab bar
function TabBar({ active, onSelect }) {
  const items = [
    { id: 'plan', icon: Icon.plan },
    { id: 'browse', icon: Icon.browse },
    { id: 'cart', icon: Icon.cart },
    { id: 'fav', icon: Icon.heart },
    { id: 'settings', icon: Icon.settings },
  ];
  return (
    <div className="tabbar">
      {items.map(({ id, icon: I }) => (
        <div
          key={id}
          className={`tab ${active === id ? 'on' : ''}`}
          onClick={() => onSelect && onSelect(id)}
        >
          <I size={20} sw={active === id ? 2.4 : 1.9} />
        </div>
      ))}
    </div>
  );
}

// Top bar
function TopBar({ title, eyebrow, right, back, onBack }) {
  return (
    <div style={{ padding: '54px 20px 14px 20px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {back && (
          <button onClick={onBack} style={{
            width: 36, height: 36, borderRadius: 999, border: '1.5px solid var(--plate-ink)',
            background: 'var(--plate-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 10, cursor: 'pointer', boxShadow: '2px 2px 0 var(--plate-ink)',
          }}><Icon.back /></button>
        )}
        {eyebrow && <div className="eyebrow" style={{ marginBottom: 4 }}>{eyebrow}</div>}
        <div className="h1">{title}</div>
      </div>
      {right}
    </div>
  );
}

window.MacrosRing = MacrosRing;
window.MacroBar = MacroBar;
window.FoodImage = FoodImage;
window.TabBar = TabBar;
window.TopBar = TopBar;
