// Plate — Macros / Nutrition deep-dive screen (week view)
function MacrosScreen({ onNav, active, onBack }) {
  const days = [
    { d: 'M', k: 1820, p: 0.95 },
    { d: 'T', k: 2040, p: 1.05 },
    { d: 'W', k: 1640, p: 0.78 },
    { d: 'T', k: 2100, p: 1.0 },
    { d: 'F', k: 1900, p: 0.9, today: true },
    { d: 'S', k: 0, p: 0 },
    { d: 'S', k: 0, p: 0 },
  ];
  const max = 2400;

  return (
    <div className="plate-screen" style={{ paddingBottom: 110 }}>
      <TopBar
        eyebrow="Friday · 16 May"
        title={<span>Macros, <span style={{ fontStyle: 'italic', fontWeight: 500 }}>tracked</span></span>}
        back onBack={onBack}
      />

      {/* Big ring summary */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="card" style={{ padding: 20, borderRadius: 26, background: 'var(--plate-ink)', borderColor: 'var(--plate-ink)', color: 'var(--plate-bg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
            <div>
              <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.55)' }}>Week so far · 5 of 7 days</div>
              <div className="display" style={{ fontSize: 36, marginTop: 4, color: 'var(--plate-bg)' }}>9,500 <span style={{ fontSize: 18, opacity: 0.55, fontWeight: 400 }}>kcal</span></div>
              <div className="small" style={{ color: 'var(--plate-lime)', marginTop: 2, fontWeight: 600 }}>−1,000 kcal vs goal · on track ✓</div>
            </div>
            <span className="sticker lime">5-day streak</span>
          </div>

          {/* Bar chart */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 120, marginTop: 8 }}>
            {days.map((day, i) => {
              const h = day.k > 0 ? (day.k / max) * 100 : 4;
              return (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{ flex: 1, width: '100%', display: 'flex', alignItems: 'flex-end' }}>
                    <div style={{
                      width: '100%',
                      height: `${h}%`,
                      borderRadius: '8px 8px 4px 4px',
                      background: day.k === 0 ? 'rgba(255,255,255,0.1)' : day.today ? 'var(--plate-lime)' : 'var(--plate-coral)',
                      border: day.today ? '1.5px solid var(--plate-lime)' : 'none',
                      boxShadow: day.today ? '0 0 0 3px rgba(200,255,62,0.25)' : 'none',
                    }}/>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 11, opacity: day.today ? 1 : 0.55 }}>{day.d}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Macro breakdown bars */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Today · Friday</div>
        <div className="card flat" style={{ padding: 18, borderRadius: 22 }}>
          <MacroFull label="Protein" val={117} target={130} unit="g" color="var(--plate-coral)" sub="of meals' avg 28g/serve"/>
          <div style={{ height: 14 }}/>
          <MacroFull label="Carbs" val={198} target={220} unit="g" color="var(--plate-butter)" sub="64% complex"/>
          <div style={{ height: 14 }}/>
          <MacroFull label="Fat" val={62} target={70} unit="g" color="var(--plate-plum)" sub="18g saturated"/>
        </div>
      </div>

      {/* Comparison */}
      <div style={{ padding: '0 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Weekly average vs goal</div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Compare lab="Protein" v="124g" t="130g" pct={95} ok/>
          <Compare lab="Carbs" v="210g" t="220g" pct={95} ok/>
          <Compare lab="Fat" v="64g" t="70g" pct={91} ok/>
        </div>
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

function MacroFull({ label, val, target, unit, color, sub }) {
  const pct = Math.min(val / target, 1) * 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>{label}</span>
        <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>
          {val}<span style={{ fontSize: 12, color: 'var(--plate-ink-3)', fontWeight: 400 }}>/{target}{unit}</span>
        </span>
      </div>
      <div className="macro-bar" style={{ height: 12 }}><span style={{ width: `${pct}%`, background: color }}/></div>
      <div className="small" style={{ marginTop: 4 }}>{sub}</div>
    </div>
  );
}

function Compare({ lab, v, t, pct, ok }) {
  return (
    <div style={{ flex: 1, padding: 14, borderRadius: 16, background: 'var(--plate-surface)', border: '1.5px solid var(--plate-ink)', boxShadow: '2px 2px 0 var(--plate-ink)' }}>
      <div className="eyebrow">{lab}</div>
      <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, marginTop: 4 }}>{v}</div>
      <div className="small tabular">goal {t}</div>
      <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: ok ? 'var(--plate-leaf)' : 'var(--plate-coral)' }}/>
        <span className="tabular small" style={{ fontWeight: 600, color: ok ? 'var(--plate-leaf)' : 'var(--plate-coral)' }}>{pct}%</span>
      </div>
    </div>
  );
}

window.MacrosScreen = MacrosScreen;
