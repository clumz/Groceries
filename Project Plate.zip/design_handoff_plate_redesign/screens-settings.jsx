// Plate — Settings (taste profile + macros + household)
function SettingsScreen({ onNav, active }) {
  return (
    <div className="plate-screen" style={{ paddingBottom: 110 }}>
      <TopBar
        eyebrow="Plate · v1.0"
        title="You & yours"
        right={
          <button style={{
            width: 44, height: 44, borderRadius: 999, border: '1.5px solid var(--plate-ink)',
            background: 'var(--plate-coral)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '2px 2px 0 var(--plate-ink)', cursor: 'pointer',
          }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>JL</span>
          </button>
        }
      />

      {/* Profile card */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="card" style={{ padding: 16, borderRadius: 22, background: 'var(--plate-lime)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 56, height: 56, borderRadius: 999, background: 'var(--plate-surface)', border: '1.5px solid var(--plate-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22 }}>
              JL
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18 }}>Jordan Lee</div>
              <div className="small">Carlton North · 4 servings · Maintain</div>
            </div>
            <button style={{ background: 'var(--plate-ink)', color: 'var(--plate-bg)', border: 'none', height: 32, padding: '0 14px', borderRadius: 999, fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12 }}>Edit</button>
          </div>
        </div>
      </div>

      {/* Daily targets card */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Daily targets</div>
        <div className="card flat" style={{ padding: 16, borderRadius: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 64, height: 64, borderRadius: 999, border: '6px solid var(--plate-coral)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <div style={{ textAlign: 'center' }}>
                <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>2.1k</div>
                <div className="eyebrow" style={{ fontSize: 8 }}>kcal</div>
              </div>
            </div>
            <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
              <Metric val="130" lab="Protein" color="var(--plate-coral)"/>
              <Metric val="220" lab="Carbs" color="var(--plate-butter)"/>
              <Metric val="70" lab="Fat" color="var(--plate-plum)"/>
            </div>
          </div>
          <button style={{ width: '100%', marginTop: 14, background: 'var(--plate-bg)', border: '1.5px solid var(--plate-line)', height: 38, borderRadius: 12, fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>
            Adjust macros
          </button>
        </div>
      </div>

      {/* Diet chips display */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, paddingLeft: 4 }}>
          <span className="eyebrow">Dietary</span>
          <span className="small" style={{ color: 'var(--plate-coral)', fontWeight: 600 }}>Edit</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          <span className="sticker lime">💪 High-protein</span>
          <span className="sticker butter">🌾 Gluten-free</span>
          <span className="sticker">🥜 Nut-free</span>
          <span className="sticker ghost" style={{ borderColor: 'var(--plate-line)', boxShadow: 'none', color: 'var(--plate-ink-3)' }}>+ Add</span>
        </div>
      </div>

      {/* Household */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Household</div>
        <div className="card flat" style={{ padding: 4, borderRadius: 18 }}>
          <Row icon="🛒" label="Preferred store" value="Woolworths"/>
          <Row icon="👥" label="Cooking for" value="2 adults · 1 kid"/>
          <Row icon="💰" label="Weekly budget" value="A$250"/>
          <Row icon="⏱" label="Cook time" value="20–40 min" last/>
        </div>
      </div>

      {/* Misc */}
      <div style={{ padding: '0 20px 16px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>App</div>
        <div className="card flat" style={{ padding: 4, borderRadius: 18 }}>
          <Row icon="🌗" label="Appearance" value="System"/>
          <Row icon="🔔" label="Notifications" value="On"/>
          <Row icon="🌿" label="Pantry" value="34 items"/>
          <Row icon="↺" label="Reset" value="" last danger/>
        </div>
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

function Metric({ val, lab, color }) {
  return (
    <div style={{ textAlign: 'center', padding: '4px 0' }}>
      <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, color }}>{val}<span style={{ fontSize: 10, color: 'var(--plate-ink-3)', fontWeight: 400, marginLeft: 1 }}>g</span></div>
      <div className="eyebrow">{lab}</div>
    </div>
  );
}

function Row({ icon, label, value, last, danger }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 12px', borderBottom: last ? 'none' : '1px solid var(--plate-line)' }}>
      <div style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--plate-bg)', border: '1px solid var(--plate-line)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15 }}>{icon}</div>
      <div style={{ flex: 1, fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 14, color: danger ? 'var(--plate-coral-deep)' : 'var(--plate-ink)' }}>{label}</div>
      {value && <span className="small tabular">{value}</span>}
      <Icon.arrow size={12}/>
    </div>
  );
}

window.SettingsScreen = SettingsScreen;
