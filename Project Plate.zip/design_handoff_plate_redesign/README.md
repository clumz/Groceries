# Handoff: Plate — Macro-First Meal Planning App Redesign

## Overview

A bold, playful redesign of **Plate**, a meal-planning app where macros (calories + protein/carbs/fat) are the always-visible hero of the experience. The aesthetic is sticker-UI: thick black outlines, hard offset shadows, saturated lime/coral accents, and large italic display type. The redesign covers 8 screens spanning the full user journey: onboarding → daily planning → recipe discovery → grocery cart → checkout → settings.

## About the Design Files

The files in this bundle are **design references created in HTML/JSX** — prototypes showing the intended look, behavior, and interaction model. They are **not production code to copy directly**.

The task is to **recreate these designs in your existing codebase** (React Native, SwiftUI, Flutter, etc.) using the patterns, navigation primitives, and component libraries already in place. If no codebase exists yet, choose the framework most appropriate for the platform (iOS-first, given the iPhone framing) and implement the designs there.

The HTML prototype runs as a single-file React app with Babel-transpiled JSX, framed inside a mock iPhone bezel on a pannable design canvas. None of the framing/canvas code (`ios-frame.jsx`, `design-canvas.jsx`, `tweaks-panel.jsx`) ships — it's only there to present the screens for review.

## Fidelity

**High-fidelity (hifi).** All colors, typography, spacing, border weights, shadow offsets, and copy are final and intentional. Recreate pixel-perfectly, but adapt to the codebase's existing primitives (use the existing `Button` component but restyle it, rather than forking a new one).

The exception is the **food imagery**: the prototype uses Unsplash URLs as placeholders. Production will use the recipe-photo CDN already in the app.

---

## Design System

### Color Tokens

```
/* Surface */
--plate-bg:       #FFF8EE   /* warm off-white app background */
--plate-surface:  #FFFFFF   /* card surface */
--plate-ink:      #1A1410   /* near-black, used for outlines, primary text, dark buttons */
--plate-ink-2:    #5C5249   /* secondary text */
--plate-ink-3:    #9C9087   /* tertiary text, eyebrows */
--plate-line:     #EDE4D5   /* hairline, track, placeholder fills */

/* Accent palette (sticker colors) */
--plate-lime:       #C8FF3E   /* hero accent, primary CTAs, "active" tab */
--plate-lime-deep:  #9FD41A
--plate-coral:      #FF6B4A   /* secondary accent, protein, alerts */
--plate-coral-deep: #E5482A
--plate-butter:     #FFD66B   /* tertiary accent, carbs */
--plate-plum:       #4A2B5C   /* dark accent, fat */
--plate-leaf:       #2D5A3D
--plate-sky:        #B8E4F0
```

**Macro color mapping** (consistent across all screens):
- Calories / overall ring → `--plate-lime`
- Protein → `--plate-coral`
- Carbs → `--plate-butter`
- Fat → `--plate-plum`

### Typography

Two families, loaded from Google Fonts:
- **Display:** `Bricolage Grotesque` (700/600) — for headings, buttons, stickers, big numbers. Italic variant used for the "playful signature" moments (welcome hero, section eyebrows).
- **Body:** `Inter` (400/500) — for paragraph copy, labels, list items.
- **Mono:** `JetBrains Mono` — for the all-caps eyebrow labels only.

Type scale (px / line-height / letter-spacing):

| Token   | Size | LH    | LS      | Use |
|---------|------|-------|---------|-----|
| display | 56+  | 0.95  | -0.03em | Hero headlines (Welcome) |
| h1      | 32   | 1.0   | -0.03em | Screen titles |
| h2      | 22   | 1.05  | -0.02em | Section headers |
| h3      | 17   | 1.15  | -0.015em| Card titles |
| body    | 14   | 1.4   | -0.01em | Default copy |
| small   | 12   | 1.3   | -0.01em | Captions |
| eyebrow | 10   | 1.3   | +0.08em | UPPERCASE mono labels |

All text uses `letter-spacing: -0.01em` baseline and `-webkit-font-smoothing: antialiased`.

### Spacing & Radius

```
--r-sm: 10px   /* small chips, inline controls */
--r-md: 16px   /* secondary cards */
--r-lg: 22px   /* primary cards */
--r-xl: 32px   /* hero cards, large surfaces */
```

Padding scale: 8 / 12 / 14 / 16 / 20 / 24 / 32 (multiples of 4).

### Shadows

The signature look is a **hard offset shadow** (no blur), not a soft drop shadow:

```
/* Sticker / button shadow — primary look */
box-shadow: 3px 3px 0 var(--plate-ink);   /* large: cards, primary buttons */
box-shadow: 2px 2px 0 var(--plate-ink);   /* small: stickers, tags */

/* Soft fallback for floating panels (rare) */
--shadow-card: 0 1px 2px rgba(0,0,0,0.04), 0 8px 28px -12px rgba(26,20,16,0.18);
```

All cards/buttons/stickers also carry a **1.5px solid `--plate-ink` border** that's never optional — the border + offset-shadow pair is what creates the sticker effect. On `:active`, translate Y by 1px to imply the press.

---

## Component Primitives

These are the reusable atoms. Every screen is built from these.

### `Sticker`
Pill-shaped tag. 6/11px padding, 999px radius, 1.5px ink border, 12px display font, 2px offset shadow.
Variants: `lime` | `coral` | `butter` | `sky` | `plum` | `ghost`.
Used for: dietary tags ("vegan", "GF"), counts ("4 left"), inline metadata.

### `Button`
52px tall, 22px horizontal padding, 999px radius, 1.5px ink border, 16px display font, 3px offset shadow.
Variants: default (ink fill, bg text) | `lime` | `coral` | `ghost`.
Modifier: `sm` (38px tall, 13px font, 14px padding).

### `Card`
22px radius, white surface, 1.5px ink border, 3px offset shadow.
`Card.flat` modifier: line-color border, soft shadow — used for nested cards inside a Card.

### `Chip`
Toggle pill. 9/14px padding, 999px radius, 1.5px ink border. White when off, ink-fill when on. `lime.on` modifier swaps to lime fill.
Used for: dietary toggles in onboarding, category filters in browse.

### `MacroRing`
SVG ring chart. 14px stroke, rounded line caps, lime progress on line-colored track. Center shows large display-font number + small label.
Composed: an outer ring (calories) with three concentric inner arcs (protein/carbs/fat) for the deep-dive view.

### `MacroBar`
8px tall, 999px radius, line-colored track with a colored fill. Three stacked bars below the ring on Plan and Recipe Detail.

### `TabBar`
Floating ink-filled pill, 18px from bottom, 12px horizontal margin, 64px tall. 5 tabs: Plan / Browse / Cart / Macros / Settings. Active tab is a 44px lime circle.

### `DayPill`
50×60px rounded-rectangle (18px radius). Stacked: weekday letter + date number. Active state inverts to ink fill with a lime dot indicator.

### Sticker Tag (absolute)
Decorative floating pills used on imagery — "🔥 hot", "vegan", "12 min". Absolutely positioned with rotation (typically -4° to +6°) for the playful collage feel.

---

## Screens

All screens are 390×844 (iPhone 14/15 logical resolution). Tab bar is global and overlaid; screen content scrolls beneath it with ~96px bottom padding to clear the tab bar.

### 1. Welcome
**Purpose:** First-launch hero. Convert visitor → onboarding.

- Dark background (`--plate-ink`), warm bg text.
- Floating "food collage" — 4 circular Unsplash food photos absolutely positioned with rotation, tagged with sticker labels ("vegan", "🔥 22g protein", etc.).
- Massive italic display headline: *"Eat like you mean it."* (56px+, mixed weight/italic).
- Two CTAs: lime "Get started" (primary), ghost "I have an account" (secondary).
- Bottom row: 3 social-proof stickers ("4.9★", "200k cooks", "B-corp").

### 2. Onboarding
**Purpose:** Capture dietary preferences and macro goals.

Three-step vertical flow within one screen (or split into 3 paginated views — matches the existing app's onboarding pattern):
1. **Diet chips** — grid of toggle chips: Vegan, Vegetarian, Pescatarian, GF, Dairy-free, Nut-free, Low-carb, High-protein, Whole30, Mediterranean. Multi-select.
2. **Goal selector** — large radio cards: "Lose fat" / "Build muscle" / "Maintain" / "Eat better". Each card has an icon and one-line description.
3. **Macro targets** — three sliders for protein/carbs/fat split (must sum to 100%). Live-updating ring preview on the right shows the resulting macro distribution. Calorie target is a separate stepper input.

Sticky bottom: progress dots + "Continue" lime button.

### 3. Plan (hero screen)
**Purpose:** Daily home. Macros are always visible at the top.

- Top: greeting + date eyebrow.
- **Hero macros card** — large `MacroRing` (calories left vs goal) + 3 stacked `MacroBar`s for protein/carbs/fat with "Xg / Yg" tabular labels.
- Horizontal `DayPill` scroller (Mon–Sun), today highlighted.
- "Today's plate" section: 3 meal cards (Breakfast / Lunch / Dinner) — each shows photo, recipe name, cook time sticker, calorie sticker, "swap" ghost button.
- "Snack ideas" horizontal scroll of small recipe cards.

### 4. Macros (deep dive)
**Purpose:** Weekly/historical macro analysis.

- Top: large concentric `MacroRing` showing today's outer ring + inner arcs for each macro.
- "This week" 7-bar chart (calories per day vs goal line). Tap a bar → that day's breakdown below.
- Full breakdown table: protein/carbs/fat with grams, % of goal, % of total cals.
- "Weekly average vs goal" stat card. Up/down arrow + delta.

### 5. Recipe Detail
**Purpose:** View a recipe and its full macros before cooking or adding to plan.

- Top: full-bleed photo (66% of screen height), tagged with floating stickers ("🌱 vegan", "22 min", "1 serves").
- Bottom sheet card (overlapping the photo by ~32px, 32px top radius):
  - Recipe title (h1) + by-line.
  - **Tabs:** "Macros" | "Recipe" | "Ingredients".
  - **Macros tab** (default): mini ring + 3 macro bars + full nutrition table (sat fat, fiber, sugar, sodium, etc.).
  - **Recipe tab:** numbered step list.
  - **Ingredients tab:** checklist with "Add to cart" CTA.
- Sticky footer: "Add to plan" lime button + heart icon.

### 6. Browse / Discover
**Purpose:** Find recipes.

- Search input at top (round, ink-bordered, with magnifier icon).
- Horizontal category chips: All / Quick / High-protein / Vegan / Comfort / Dessert / Soup. (Multi-select.)
- **"Editor's pick"** spotlight card — large landscape recipe with overlay tags.
- 2-column grid of recipe cards. Each: photo (1:1 ratio), tags, title, cook time + calorie row.

### 7. Cart
**Purpose:** Review the auto-generated grocery list.

- Header: "Your cart" + total item count + estimated $ total.
- Store toggle: Whole Foods / Trader Joe's / Local. Sticker-style segmented control.
- **Smart-substitution banner** (lime card with hard shadow): "We swapped 3 items to save $4.20. [View]"
- Sectioned list: Produce / Protein / Pantry / Dairy. Each item: thumbnail, name, qty, price, swap icon, delete X.
- Sticky footer: "Checkout — $XX.XX" lime button.

### 8. Checkout
**Purpose:** Finalize delivery.

- **Delivery slot picker** — horizontal pills: "Today 5–7p" / "Tomorrow 10a" / etc. Each slot shows price modifier.
- Address card with "Change" link.
- Payment method card (last 4 digits + edit).
- Order summary: subtotal / delivery / tip / total. Tip is a 4-button selector (15/18/20/Custom).
- Sticky footer: "Place order" lime button. After tap: success state with check-mark sticker animation.

### 9. Settings (bonus 9th screen)
**Purpose:** Manage profile, taste, household, dietary tags.

- Profile header card: avatar + name + "Member since" eyebrow.
- "Daily targets" mini ring card — tappable to edit goals (re-enters macro slider flow).
- Sections: Taste profile / Household size / Dietary stickers (chips again) / Notifications / Account / Help.
- Each section is a `Card` with rows; chevron right on tap.

---

## Interactions & Behavior

- **Tab bar nav:** Tap a tab → instantly swap screen. The active pill animates with a 0.35s `cubic-bezier(0.16, 1, 0.3, 1)` pop-in.
- **Buttons:** `:active` translates Y by 1px (no shadow change) to imply the sticker pressing into the page.
- **Chips/Day pills:** 0.12s linear color transition on toggle.
- **Recipe detail:** Tabs swap content with a 200ms cross-fade. Photo parallax — translates up at 0.5× scroll speed for the first 100px.
- **Macro ring:** Animates from 0 to current value over 700ms with spring easing on first mount. Subsequent updates animate the delta only.
- **Cart swaps:** Tapping the swap icon on an item slides in a substitution drawer from bottom (60% height).
- **Onboarding sliders:** Three sliders are linked — adjusting one reduces the other two proportionally so total stays 100%. Show a live percentage label above each thumb.

---

## State Management

Minimum global state needed:

- `user.profile` — name, avatar, member-since, household-size
- `user.diet` — string[] of active dietary tags
- `user.goals` — `{ calories, protein, carbs, fat, intent }` where intent ∈ {lose, build, maintain, better}
- `plan.byDay` — `{ [ISO date]: { breakfast, lunch, dinner, snacks } }`
- `intake.byDay` — `{ [ISO date]: { calories, protein, carbs, fat } }` (derived from logged meals)
- `cart.items` — `Item[]` with `{ id, name, qty, unit, price, section, swapSuggestion? }`
- `cart.store` — current selected store
- `recipes.byId` — recipe data including full nutrition
- `ui.activeTab` — current tab
- `ui.density` — `'cozy' | 'compact'` (the only Tweak exposed in the prototype)

Derived selectors to implement:
- `getRemainingMacros(date)` — goal − intake
- `getWeeklyAverage()` — last 7 days mean per macro
- `getCartSubtotal()` — sum of items × qty

---

## Tweaks (variants exposed in the prototype)

The prototype includes one user-facing variant via the Tweaks panel:

- **`density`**: `'cozy'` (14px card padding, current default) | `'compact'` (10px card padding, tighter row gaps).

Recommend exposing this as a setting in production under Settings → Display.

---

## Assets

- **Food photos:** Currently sourced from Unsplash (URLs in each `screens-*.jsx` file). Replace with the production recipe-photo pipeline.
- **Icons:** All icons are inline SVG in `icons.jsx` — single-stroke, 1.75 stroke-width, rounded line caps. Drawn to match the playful sticker aesthetic. Reference but redraw using the codebase's icon system (e.g., SF Symbols, Lucide, custom set).
- **Fonts:** Bricolage Grotesque + Inter from Google Fonts. License is OFL — safe for commercial use. Self-host in production.

---

## Files in This Bundle

| File | Purpose |
|------|---------|
| `Plate.html` | Entry point — loads everything, sets up the iOS frame on a design canvas |
| `styles.css` | All design tokens + utility classes. **The source of truth for the visual system.** |
| `icons.jsx` | Inline SVG icon components |
| `primitives.jsx` | `Sticker`, `Button`, `Card`, `Chip`, `MacroRing`, `MacroBar`, `TabBar`, `DayPill` |
| `screens-welcome.jsx` | Welcome / first-launch screen |
| `screens-onboarding.jsx` | Diet + goal + macro-target onboarding |
| `screens-plan.jsx` | Daily plan (the hero screen) |
| `screens-macros.jsx` | Macros deep-dive |
| `screens-recipe.jsx` | Recipe detail with tabs |
| `screens-browse.jsx` | Discover / search recipes |
| `screens-cart.jsx` | Grocery cart |
| `screens-checkout.jsx` | Delivery + payment |
| `screens-settings.jsx` | Profile + preferences |
| `ios-frame.jsx` | Mock iPhone bezel — **do not ship**, it's just for presenting the design |
| `design-canvas.jsx` | Pannable canvas wrapper — **do not ship**, presentation only |
| `tweaks-panel.jsx` | In-prototype Tweaks UI — **do not ship** |

---

## Implementation Notes

1. **Start with the design tokens** in `styles.css`. Port all CSS custom properties to your theme system before writing any components.
2. **Build the primitives next** (Button, Card, Sticker, Chip, MacroRing, MacroBar, TabBar). Get these pixel-perfect — every screen depends on them.
3. **The sticker shadow trick** (`box-shadow: 3px 3px 0 ink-color`) is the visual signature. Don't substitute with a soft drop shadow — it loses the whole identity.
4. **Macro colors must stay consistent** across screens (lime=cal, coral=protein, butter=carbs, plum=fat). This is how users learn the legend.
5. **The tab bar is always visible** — every screen reserves 96px bottom padding for it. Don't push it off-screen on scroll.
6. **For React Native:** the offset shadow doesn't work natively. Use a thin `View` of ink color positioned 3px down-right behind each card, or use a library like `react-native-shadow-2`.
