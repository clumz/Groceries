// Plate — Plan screen (Hero macros ring + day picker + meals)
const PLATE_IMG = {
  pasta: 'https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5?w=600&q=80',
  salad: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80',
  curry: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=600&q=80',
  bowl: 'https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=600&q=80',
  taco: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&q=80',
  meze: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?w=600&q=80',
  steak: 'https://images.unsplash.com/photo-1558030006-450675393462?w=600&q=80',
  ramen: 'https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=600&q=80',
  thai: 'https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?w=600&q=80',
  greek: 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=600&q=80',
  oats: 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=600&q=80',
  fruit: 'https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?w=600&q=80',
};
window.PLATE_IMG = PLATE_IMG;

const DAYS = [
  { d: 'Mon', n: 12, k: 1820, ok: true },
  { d: 'Tue', n: 13, k: 2040, ok: true },
  { d: 'Wed', n: 14, k: 1640, ok: true, today: true },
  { d: 'Thu', n: 15, k: null, ok: false },
  { d: 'Fri', n: 16, k: null, ok: false },
  { d: 'Sat', n: 17, k: null, ok: false },
  { d: 'Sun', n: 18, k: null, ok: false },
];

function PlanScreen({ density = 'cozy', onNav, active = 'plan' }) {
  const [day, setDay] = useState(2);
  return (
    <div className={`plate-screen density-${density}`} style={{ paddingBottom: 110 }}>
      <TopBar
        eyebrow="Wed · 14 May"
        title={<span>This <span style={{ fontStyle: 'italic', fontWeight: 500 }}>week</span></span>}
        right={
          <button style={{
            width: 44, height: 44, borderRadius: 999, border: '1.5px solid var(--plate-ink)',
            background: 'var(--plate-lime)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', boxShadow: '2px 2px 0 var(--plate-ink)',
          }}><Icon.sparkle size={18} /></button>
        }
      />

      {/* Hero macros card */}
      <div style={{ padding: '0 16px 16px 16px' }}>
        <div className="card" style={{ padding: 18, background: 'var(--plate-bg)', borderRadius: 26 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <div>
              <div className="eyebrow">today's plate</div>
              <div className="h2" style={{ marginTop: 4 }}>Smashing it.</div>
            </div>
            <span className="sticker lime"><Icon.flame size={11} sw={2.5}/> 3-day streak</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 6 }}>
            <MacrosRing size={148} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <MacroBar label="Protein" val={92} target={130} color="var(--plate-coral)" />
              <MacroBar label="Carbs" val={180} target={220} color="var(--plate-butter)" />
              <MacroBar label="Fat" val={58} target={70} color="var(--plate-plum)" />
            </div>
          </div>

          <div style={{ display: 'flex', gap: 6, marginTop: 14, paddingTop: 14, borderTop: '1px dashed var(--plate-line)' }}>
            <div style={{ flex: 1 }}>
              <div className="eyebrow">week avg</div>
              <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>1,830 <span style={{color:'var(--plate-ink-3)',fontWeight:400}}>kcal</span></div>
            </div>
            <div style={{ flex: 1 }}>
              <div className="eyebrow">vs goal</div>
              <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14, color: 'var(--plate-leaf)' }}>−270 ✓</div>
            </div>
            <div style={{ flex: 1 }}>
              <div className="eyebrow">budget</div>
              <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>$184 <span style={{color:'var(--plate-ink-3)',fontWeight:400}}>/250</span></div>
            </div>
          </div>
        </div>
      </div>

      {/* Day strip */}
      <div className="row-scroll" style={{ padding: '0 16px 18px 16px' }}>
        {DAYS.map((dd, i) => (
          <div key={dd.d} className={`day-pill ${day === i ? 'on' : ''}`} onClick={() => setDay(i)}>
            <div className="eyebrow" style={{ color: day === i ? 'rgba(255,255,255,0.6)' : 'var(--plate-ink-3)' }}>{dd.d}</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{dd.n}</div>
            {dd.ok && <div className="dot" style={{ background: day === i ? 'var(--plate-lime)' : 'var(--plate-coral)' }} />}
          </div>
        ))}
      </div>

      {/* Meals */}
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="eyebrow" style={{ paddingLeft: 4 }}>Wednesday · 3 meals</div>

        <MealCard
          slot="Lunch" time="12:30"
          name="Lemon herb chicken bowl"
          tag="High protein"
          img={PLATE_IMG.bowl}
          time_m={20} kcal={520} p={42} c={48} f={18}
        />
        <MealCard
          slot="Snack" time="15:30"
          name="Greek yoghurt + berries"
          tag="GF"
          img={PLATE_IMG.fruit}
          time_m={3} kcal={210} p={18} c={28} f={4}
          compact
        />
        <MealCard
          slot="Dinner" time="19:00"
          name="Miso-butter salmon, rice & greens"
          tag="Omega-3"
          tagColor="butter"
          img={PLATE_IMG.ramen}
          time_m={28} kcal={680} p={48} c={62} f={28}
        />

        <button className="btn lime" style={{ marginTop: 4 }}>
          <Icon.sparkle size={14}/> Generate next week
        </button>
      </div>

      <TabBar active={active} onSelect={onNav} />
    </div>
  );
}

function MealCard({ slot, time, name, tag, tagColor='lime', img, time_m, kcal, p, c, f, compact }) {
  return (
    <div className="card card-recipe" style={{ padding: 12, display: 'flex', gap: 12, alignItems: 'stretch' }}>
      <div style={{ position: 'relative', width: compact ? 72 : 100, flexShrink: 0 }}>
        <img src={img} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 14, border: '1.5px solid var(--plate-ink)' }} />
      </div>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
            <span className="eyebrow">{slot}</span>
            <span style={{ width: 3, height: 3, borderRadius: 999, background: 'var(--plate-ink-3)' }}></span>
            <span className="eyebrow">{time}</span>
            {tag && <span className={`sticker ${tagColor}`} style={{ marginLeft: 'auto', padding: '3px 8px', fontSize: 10, boxShadow: '1.5px 1.5px 0 var(--plate-ink)' }}>{tag}</span>}
          </div>
          <div className="h3" style={{ lineHeight: 1.15 }}>{name}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <span className="small tabular" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon.clock size={12}/>{time_m}m
          </span>
          <span className="small tabular" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon.flame size={12}/>{kcal}
          </span>
          <span className="small tabular" style={{ marginLeft: 'auto' }}>
            <span style={{ color: 'var(--plate-coral)', fontWeight: 600 }}>{p}p</span>{' · '}
            <span style={{ color: 'var(--plate-butter)', filter: 'brightness(0.7)', fontWeight: 600 }}>{c}c</span>{' · '}
            <span style={{ color: 'var(--plate-plum)', fontWeight: 600 }}>{f}f</span>
          </span>
        </div>
      </div>
    </div>
  );
}

window.PlanScreen = PlanScreen;
window.MealCard = MealCard;
