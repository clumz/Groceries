// Plate — Recipe detail with full macros
function RecipeScreen({ onNav, active, onBack }) {
  const [serv, setServ] = useState(2);
  const [tab, setTab] = useState('macros');

  return (
    <div className="plate-screen" style={{ paddingBottom: 110 }}>
      {/* Hero image */}
      <div style={{ position: 'relative', height: 320, overflow: 'hidden' }}>
        <img src={PLATE_IMG.ramen} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.25), transparent 30%, transparent 60%, var(--plate-bg))' }}/>

        <div style={{ position: 'absolute', top: 54, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{
            width: 40, height: 40, borderRadius: 999, border: '1.5px solid var(--plate-ink)',
            background: 'var(--plate-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', boxShadow: '2px 2px 0 var(--plate-ink)',
          }}><Icon.back/></button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ width: 40, height: 40, borderRadius: 999, border: '1.5px solid var(--plate-ink)', background: 'var(--plate-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '2px 2px 0 var(--plate-ink)' }}>
              <Icon.heart fill="var(--plate-coral)" size={18}/>
            </button>
            <button style={{ width: 40, height: 40, borderRadius: 999, border: '1.5px solid var(--plate-ink)', background: 'var(--plate-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '2px 2px 0 var(--plate-ink)' }}>
              <Icon.swap size={16}/>
            </button>
          </div>
        </div>

        <div style={{ position: 'absolute', top: 110, right: 16, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
          <span className="sticker butter">High protein</span>
          <span className="sticker lime" style={{ transform: 'rotate(2deg)' }}>GF · DF</span>
        </div>
      </div>

      {/* Title */}
      <div style={{ padding: '0 20px', marginTop: -8 }}>
        <div className="eyebrow">Japanese · Dinner</div>
        <div className="display" style={{ fontSize: 32, marginTop: 6 }}>
          Miso-butter salmon<br/>
          <span style={{ fontStyle: 'italic', fontWeight: 500 }}>with rice & greens</span>
        </div>

        <div style={{ display: 'flex', gap: 16, marginTop: 14, alignItems: 'center' }}>
          <Stat icon={<Icon.clock/>} val="28m" lab="cook"/>
          <span style={{ width: 1, height: 32, background: 'var(--plate-line)' }}/>
          <Stat icon={<Icon.flame/>} val="680" lab="kcal"/>
          <span style={{ width: 1, height: 32, background: 'var(--plate-line)' }}/>
          <Stat val="$12.40" lab="per serve"/>
        </div>
      </div>

      {/* Tab strip */}
      <div style={{ padding: '20px 20px 0 20px' }}>
        <div style={{ display: 'flex', gap: 6, padding: 4, background: 'var(--plate-surface)', borderRadius: 999, border: '1.5px solid var(--plate-ink)' }}>
          {['macros','recipe','ingredients'].map(t => (
            <div key={t} onClick={() => setTab(t)} style={{
              flex: 1, padding: '8px 0', textAlign: 'center', borderRadius: 999,
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13,
              background: tab === t ? 'var(--plate-ink)' : 'transparent',
              color: tab === t ? 'var(--plate-bg)' : 'var(--plate-ink)',
              cursor: 'pointer', textTransform: 'capitalize',
            }}>{t}</div>
          ))}
        </div>
      </div>

      {/* Tab content */}
      {tab === 'macros' && <MacroDetail/>}
      {tab === 'recipe' && <RecipeSteps/>}
      {tab === 'ingredients' && <Ingredients/>}

      {/* Servings + add to cart */}
      <div style={{ position: 'fixed', bottom: 100, left: '50%', transform: 'translateX(-50%)', width: 374, zIndex: 4 }}>
        <div className="card" style={{ padding: 8, paddingLeft: 14, display: 'flex', alignItems: 'center', gap: 10, borderRadius: 999, background: 'var(--plate-ink)', borderColor: 'var(--plate-ink)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button onClick={() => setServ(Math.max(1, serv-1))} style={{ width: 32, height: 32, borderRadius: 999, border: 'none', background: 'rgba(255,255,255,0.15)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon.minus size={14}/></button>
            <span className="tabular" style={{ color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, minWidth: 36, textAlign: 'center' }}>{serv} <span style={{ fontSize: 11, opacity: 0.6, fontWeight: 400 }}>serv</span></span>
            <button onClick={() => setServ(Math.min(8, serv+1))} style={{ width: 32, height: 32, borderRadius: 999, border: 'none', background: 'rgba(255,255,255,0.15)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon.plus size={14}/></button>
          </div>
          <div style={{ flex: 1 }}/>
          <button className="btn lime sm" style={{ height: 44, padding: '0 18px', boxShadow: 'none' }}>
            Add to cart · ${(12.4*serv).toFixed(2)}
          </button>
        </div>
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

function Stat({ icon, val, lab }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        {icon}
        <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{val}</span>
      </div>
      <span className="eyebrow">{lab}</span>
    </div>
  );
}

function MacroDetail() {
  return (
    <div style={{ padding: '16px 20px 0 20px' }}>
      <div className="card" style={{ padding: 18, background: 'var(--plate-bg)', borderRadius: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <MacrosRing size={130} kcal={680} target={2100}/>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <MacroBar label="Protein" val={48} target={130} color="var(--plate-coral)" />
            <MacroBar label="Carbs" val={62} target={220} color="var(--plate-butter)" />
            <MacroBar label="Fat" val={28} target={70} color="var(--plate-plum)" />
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 14, borderTop: '1px dashed var(--plate-line)' }}>
          <MicroStat label="Fiber" val="6g"/>
          <MicroStat label="Sugar" val="4g"/>
          <MicroStat label="Sodium" val="780mg"/>
          <MicroStat label="Iron" val="22%"/>
        </div>
      </div>

      <div style={{ marginTop: 14, marginBottom: 90 }}>
        <div className="eyebrow" style={{ marginBottom: 8 }}>This fits your week</div>
        <div className="card flat" style={{ padding: 14, borderRadius: 18, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 999, background: 'var(--plate-lime)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1.5px solid var(--plate-ink)' }}>
            <Icon.check size={16}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>Hits your protein goal</div>
            <div className="small">+48g brings today to 140g · target 130g</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RecipeSteps() {
  const steps = [
    'Whisk miso, butter, mirin and a touch of soy.',
    'Pat salmon dry. Brush with miso butter, set aside.',
    'Cook rice. Steam broccolini and snow peas.',
    'Sear salmon skin-side up 3 min, flip 2 min, glaze.',
    'Plate rice, salmon, greens. Drizzle pan sauce, sesame.',
  ];
  return (
    <div style={{ padding: '16px 20px 110px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
      {steps.map((s, i) => (
        <div key={i} style={{ display: 'flex', gap: 12, padding: 14, background: 'var(--plate-surface)', borderRadius: 16, border: '1.5px solid var(--plate-line)' }}>
          <div style={{ width: 28, height: 28, borderRadius: 999, background: i === 0 ? 'var(--plate-lime)' : 'var(--plate-bg)', border: '1.5px solid var(--plate-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{i+1}</div>
          <div style={{ fontSize: 14, lineHeight: 1.5, color: 'var(--plate-ink)' }}>{s}</div>
        </div>
      ))}
    </div>
  );
}

function Ingredients() {
  const ings = [
    { n: 'Salmon fillets', q: '2 × 180g', tag: 'Fresh' },
    { n: 'White miso paste', q: '2 tbsp' },
    { n: 'Unsalted butter', q: '40g' },
    { n: 'Jasmine rice', q: '1 cup' },
    { n: 'Broccolini', q: '1 bunch', tag: 'Fresh' },
    { n: 'Snow peas', q: '150g', tag: 'Fresh' },
    { n: 'Mirin', q: '1 tbsp' },
    { n: 'Sesame seeds', q: '1 tsp' },
  ];
  return (
    <div style={{ padding: '16px 20px 110px 20px' }}>
      <div className="card flat" style={{ padding: 4, borderRadius: 18 }}>
        {ings.map((i, idx) => (
          <div key={i.n} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderBottom: idx === ings.length-1 ? 'none' : '1px solid var(--plate-line)' }}>
            <div style={{ width: 18, height: 18, borderRadius: 6, border: '1.5px solid var(--plate-ink)', background: 'var(--plate-lime)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon.check size={11}/>
            </div>
            <div style={{ flex: 1, fontSize: 14, fontFamily: 'var(--font-display)', fontWeight: 500 }}>{i.n}</div>
            {i.tag && <span className="sticker ghost" style={{ padding: '3px 8px', fontSize: 10, border: '1px solid var(--plate-line)', boxShadow: 'none', color: 'var(--plate-leaf)' }}>{i.tag}</span>}
            <span className="tabular small" style={{ color: 'var(--plate-ink)' }}>{i.q}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

window.RecipeScreen = RecipeScreen;
