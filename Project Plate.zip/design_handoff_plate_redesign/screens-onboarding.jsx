// Plate — Onboarding screen (preferences + macros goals)
function OnboardingScreen({ onNav, active }) {
  const [diet, setDiet] = useState(new Set(['high-protein', 'gluten-free']));
  const [cuisine, setCuisine] = useState(new Set(['italian', 'thai', 'med']));
  const [goal, setGoal] = useState('maintain');
  const [protein, setProtein] = useState(130);
  const [kcal, setKcal] = useState(2100);

  const toggle = (s, setS) => (k) => {
    const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); setS(n);
  };

  const dietOpts = [
    { k: 'vegan', l: 'Vegan', e: '🌱' },
    { k: 'vegetarian', l: 'Vegetarian', e: '🥬' },
    { k: 'pescatarian', l: 'Pescatarian', e: '🐟' },
    { k: 'gluten-free', l: 'Gluten-free', e: '🌾' },
    { k: 'dairy-free', l: 'Dairy-free', e: '🥛' },
    { k: 'nut-free', l: 'Nut-free', e: '🥜' },
    { k: 'high-protein', l: 'High-protein', e: '💪' },
    { k: 'low-carb', l: 'Low-carb', e: '🍞' },
    { k: 'keto', l: 'Keto', e: '🥑' },
  ];

  const cuisineOpts = [
    { k: 'italian', l: 'Italian' },
    { k: 'thai', l: 'Thai' },
    { k: 'med', l: 'Mediterranean' },
    { k: 'japanese', l: 'Japanese' },
    { k: 'indian', l: 'Indian' },
    { k: 'mexican', l: 'Mexican' },
    { k: 'mid-east', l: 'Middle Eastern' },
    { k: 'aussie', l: 'Modern Australian' },
  ];

  return (
    <div className="plate-screen" style={{ paddingBottom: 110 }}>
      <div style={{ padding: '54px 20px 8px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <div className="eyebrow tabular">Step 3 / 5</div>
          <div style={{ flex: 1, height: 6, background: 'var(--plate-line)', borderRadius: 999, overflow: 'hidden' }}>
            <div style={{ width: '60%', height: '100%', background: 'var(--plate-ink)' }} />
          </div>
        </div>
        <div className="display" style={{ fontSize: 38 }}>
          What fuels<br/><span style={{ fontStyle: 'italic', fontWeight: 500 }}>you</span>?
        </div>
        <div className="body" style={{ marginTop: 8 }}>Tap anything that applies. We'll mix this with your macros.</div>
      </div>

      {/* Dietary chips */}
      <div style={{ padding: '18px 16px 8px 16px' }}>
        <div className="eyebrow" style={{ marginBottom: 10, paddingLeft: 4 }}>Diet</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {dietOpts.map(o => (
            <div key={o.k} className={`chip ${diet.has(o.k) ? 'on lime' : ''}`} onClick={() => toggle(diet, setDiet)(o.k)}>
              <span>{o.e}</span><span>{o.l}</span>
              {diet.has(o.k) && <Icon.check size={12}/>}
            </div>
          ))}
        </div>
      </div>

      {/* Cuisines */}
      <div style={{ padding: '18px 16px 8px 16px' }}>
        <div className="eyebrow" style={{ marginBottom: 10, paddingLeft: 4 }}>Loved cuisines</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {cuisineOpts.map(o => (
            <div key={o.k} className={`chip ${cuisine.has(o.k) ? 'on' : ''}`} onClick={() => toggle(cuisine, setCuisine)(o.k)}>
              {cuisine.has(o.k) && <Icon.check size={11}/>}<span>{o.l}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Goal */}
      <div style={{ padding: '18px 16px 8px 16px' }}>
        <div className="eyebrow" style={{ marginBottom: 10, paddingLeft: 4 }}>Goal</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { k: 'lean', l: 'Lean down', sub: '−400 kcal' },
            { k: 'maintain', l: 'Maintain', sub: 'balanced' },
            { k: 'build', l: 'Build', sub: '+300 kcal' },
          ].map(g => (
            <div key={g.k} onClick={() => setGoal(g.k)} style={{
              flex: 1, padding: '14px 10px', borderRadius: 18,
              border: '1.5px solid var(--plate-ink)',
              background: goal === g.k ? 'var(--plate-coral)' : 'var(--plate-surface)',
              color: goal === g.k ? '#fff' : 'var(--plate-ink)',
              boxShadow: goal === g.k ? '3px 3px 0 var(--plate-ink)' : 'none',
              cursor: 'pointer', textAlign: 'center',
            }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{g.l}</div>
              <div className="tabular" style={{ fontSize: 11, opacity: 0.75, marginTop: 2 }}>{g.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily targets */}
      <div style={{ padding: '18px 16px 8px 16px' }}>
        <div className="eyebrow" style={{ marginBottom: 10, paddingLeft: 4 }}>Daily targets</div>
        <div className="card" style={{ padding: 16, borderRadius: 22, background: 'var(--plate-bg)' }}>
          <SliderRow label="Calories" val={kcal} unit="kcal" min={1400} max={3200} step={50} setVal={setKcal} color="var(--plate-coral)" />
          <SliderRow label="Protein" val={protein} unit="g" min={60} max={220} step={5} setVal={setProtein} color="var(--plate-leaf)" />
          <div style={{ display: 'flex', gap: 8, marginTop: 14, paddingTop: 14, borderTop: '1px dashed var(--plate-line)' }}>
            <MicroStat label="Carbs" val="220g" />
            <MicroStat label="Fat" val="70g" />
            <MicroStat label="Fiber" val="30g" />
          </div>
        </div>
      </div>

      <div style={{ padding: '20px 16px 0 16px', display: 'flex', gap: 10 }}>
        <button className="btn ghost" style={{ flex: 0.6 }}>Back</button>
        <button className="btn lime" style={{ flex: 1.4 }}>
          Continue <Icon.arrow size={14}/>
        </button>
      </div>

      <TabBar active={active} onSelect={onNav} />
    </div>
  );
}

function SliderRow({ label, val, unit, min, max, step, setVal, color }) {
  const pct = ((val - min) / (max - min)) * 100;
  return (
    <div style={{ marginTop: 6, marginBottom: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>{label}</span>
        <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18 }}>
          {val.toLocaleString()}<span style={{ fontSize: 12, color: 'var(--plate-ink-3)', marginLeft: 2 }}>{unit}</span>
        </span>
      </div>
      <div style={{ position: 'relative', height: 28, display: 'flex', alignItems: 'center' }}>
        <div style={{ width: '100%', height: 8, background: 'var(--plate-line)', borderRadius: 999, position: 'relative' }}>
          <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 999 }} />
          <div style={{
            position: 'absolute', left: `calc(${pct}% - 12px)`, top: -8,
            width: 24, height: 24, borderRadius: 999, background: 'var(--plate-surface)',
            border: '2px solid var(--plate-ink)', boxShadow: '2px 2px 0 var(--plate-ink)',
          }} />
        </div>
        <input
          type="range" min={min} max={max} step={step} value={val}
          onChange={e => setVal(Number(e.target.value))}
          style={{ position: 'absolute', inset: 0, opacity: 0, width: '100%', cursor: 'pointer' }}
        />
      </div>
    </div>
  );
}

function MicroStat({ label, val }) {
  return (
    <div style={{ flex: 1 }}>
      <div className="eyebrow">{label}</div>
      <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14, marginTop: 2 }}>{val}</div>
    </div>
  );
}

window.OnboardingScreen = OnboardingScreen;
