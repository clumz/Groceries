// Plate — Welcome / Landing screen
function WelcomeScreen({ onNav }) {
  return (
    <div className="plate-screen" style={{ background: 'var(--plate-ink)', color: 'var(--plate-bg)', position: 'relative', overflow: 'hidden' }}>
      {/* Background lime blob */}
      <div style={{
        position: 'absolute', top: -120, left: -100, width: 400, height: 400,
        background: 'var(--plate-lime)', borderRadius: '50%', opacity: 0.92,
      }}/>
      <div style={{
        position: 'absolute', top: 200, right: -80, width: 220, height: 220,
        background: 'var(--plate-coral)', borderRadius: '50%',
      }}/>

      {/* Photo collage */}
      <div style={{ position: 'relative', height: 400, marginTop: 30 }}>
        <FloatPhoto src={PLATE_IMG.bowl} top={62} left={20} w={130} h={170} rot={-6} sticker="High protein" stickerColor="lime"/>
        <FloatPhoto src={PLATE_IMG.curry} top={30} right={18} w={120} h={150} rot={4} sticker="22m" stickerColor="butter"/>
        <FloatPhoto src={PLATE_IMG.salad} top={210} left="50%" w={150} h={130} rot={-2} translate="-50%" z={3} sticker="Fresh" stickerColor="coral"/>
      </div>

      {/* Wordmark + copy */}
      <div style={{ position: 'relative', padding: '20px 24px 0 24px', zIndex: 4 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 24 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10, background: 'var(--plate-lime)',
            border: '1.5px solid var(--plate-bg)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22, color: 'var(--plate-ink)',
          }}>P</div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22, letterSpacing: -0.02 }}>Plate</span>
        </div>

        <div className="display" style={{ fontSize: 52, color: 'var(--plate-bg)' }}>
          Eat well,<br/>
          <span style={{ fontStyle: 'italic', fontWeight: 500, color: 'var(--plate-lime)' }}>every</span> week.
        </div>

        <div style={{ marginTop: 14, fontSize: 16, lineHeight: 1.4, opacity: 0.75, maxWidth: 320 }}>
          AI-personalised meal plans matched to your macros, dietary needs, and weekly budget — straight to Woolies or Coles.
        </div>

        {/* Stat row */}
        <div style={{ display: 'flex', gap: 12, marginTop: 22 }}>
          <Stat2 v="222" l="recipes"/>
          <Stat2 v="2.1k" l="kcal target"/>
          <Stat2 v="7" l="day plan"/>
        </div>

        {/* CTAs */}
        <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button className="btn lime" onClick={() => onNav && onNav('onboarding')} style={{ height: 58, fontSize: 17, justifyContent: 'space-between', paddingLeft: 24, paddingRight: 18 }}>
            <span>Get started</span>
            <span style={{
              width: 36, height: 36, borderRadius: 999, background: 'var(--plate-ink)', color: 'var(--plate-bg)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon.arrow size={14}/></span>
          </button>
          <div style={{ textAlign: 'center', fontSize: 13, opacity: 0.6, marginTop: 4 }}>
            Already have a Plate? <span style={{ color: 'var(--plate-lime)', fontWeight: 600 }}>Sign in</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat2({ v, l }) {
  return (
    <div style={{ flex: 1, padding: '12px 14px', borderRadius: 16, background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}>
      <div className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 22 }}>{v}</div>
      <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.5)' }}>{l}</div>
    </div>
  );
}

function FloatPhoto({ src, top, left, right, w, h, rot=0, translate, z=1, sticker, stickerColor }) {
  return (
    <div style={{
      position: 'absolute', top, left, right, width: w, height: h,
      transform: `${translate ? `translateX(${translate}) ` : ''}rotate(${rot}deg)`,
      zIndex: z,
    }}>
      <div style={{
        width: '100%', height: '100%', borderRadius: 18, overflow: 'hidden',
        border: '2.5px solid var(--plate-bg)',
        boxShadow: '6px 6px 0 rgba(0,0,0,0.4)',
      }}>
        <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
      </div>
      {sticker && <span className={`tag-sticker ${stickerColor}`} style={{
        bottom: -8, left: '50%', transform: 'translateX(-50%) rotate(-3deg)',
        background: stickerColor === 'lime' ? 'var(--plate-lime)' : stickerColor === 'butter' ? 'var(--plate-butter)' : 'var(--plate-coral)',
        color: stickerColor === 'coral' ? '#fff' : 'var(--plate-ink)',
        whiteSpace: 'nowrap',
      }}>{sticker}</span>}
    </div>
  );
}

window.WelcomeScreen = WelcomeScreen;
