// Plate — Checkout
function CheckoutScreen({ onNav, active, onBack }) {
  const [slot, setSlot] = useState(1);
  const slots = [
    { d: 'Today', t: '5:00–6:00pm', price: 'Free', bonus: '🌟 Tonight' },
    { d: 'Today', t: '7:00–8:00pm', price: '$2.00' },
    { d: 'Tomorrow', t: '8:00–9:00am', price: 'Free' },
    { d: 'Tomorrow', t: '12:00–1:00pm', price: '$2.00' },
  ];

  return (
    <div className="plate-screen" style={{ paddingBottom: 200 }}>
      <TopBar
        eyebrow="Final step"
        title="Checkout"
        back onBack={onBack}
      />

      {/* Address */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Deliver to</div>
        <div className="card flat" style={{ padding: 16, borderRadius: 20, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--plate-lime)', border: '1.5px solid var(--plate-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            🏠
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>Home</div>
            <div className="small">42 Cuthbert St, Carlton North VIC 3054</div>
          </div>
          <button style={{ background: 'transparent', border: 'none', color: 'var(--plate-coral)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13 }}>Change</button>
        </div>
      </div>

      {/* Delivery slot */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Delivery slot</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {slots.map((s, i) => (
            <div key={i} onClick={() => setSlot(i)} style={{
              padding: '12px 14px', borderRadius: 16,
              border: '1.5px solid var(--plate-ink)',
              background: slot === i ? 'var(--plate-ink)' : 'var(--plate-surface)',
              color: slot === i ? 'var(--plate-bg)' : 'var(--plate-ink)',
              boxShadow: slot === i ? '3px 3px 0 var(--plate-ink)' : 'none',
              display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 999,
                border: `2px solid ${slot === i ? 'var(--plate-lime)' : 'var(--plate-ink)'}`,
                background: slot === i ? 'var(--plate-lime)' : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>{slot === i && <Icon.check size={11}/>}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>{s.d} · {s.t}</div>
                {s.bonus && <div className="small tabular" style={{ color: slot === i ? 'rgba(255,255,255,0.7)' : 'var(--plate-coral)' }}>{s.bonus}</div>}
              </div>
              <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>{s.price}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Payment */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div className="eyebrow" style={{ marginBottom: 8, paddingLeft: 4 }}>Payment</div>
        <div className="card flat" style={{ padding: 16, borderRadius: 20, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 44, height: 30, borderRadius: 6, background: 'var(--plate-plum)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 11, letterSpacing: 0.5 }}>
            VISA
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14 }}>•••• 4218</div>
            <div className="small">Apple Pay available</div>
          </div>
          <Icon.swap size={14}/>
        </div>
      </div>

      {/* Summary */}
      <div style={{ padding: '0 20px 14px 20px' }}>
        <div className="card" style={{ padding: 16, borderRadius: 22, background: 'var(--plate-bg)' }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Order summary</div>
          <SumRow l="Groceries · 28 items" v="$184.20"/>
          <SumRow l="Delivery" v="Free" hl/>
          <SumRow l="Smart-sub savings" v="−$4.10" hl green/>
          <div style={{ height: 1, background: 'var(--plate-line)', margin: '10px 0' }}/>
          <SumRow l={<span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>Total</span>} v={<span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18 }}>$180.10</span>}/>
        </div>
      </div>

      {/* CTA */}
      <div style={{ position: 'fixed', bottom: 96, left: '50%', transform: 'translateX(-50%)', width: 374, zIndex: 4 }}>
        <button className="btn coral" style={{ width: '100%', height: 56, fontSize: 16 }}>
          Place order · $180.10 <Icon.arrow size={14}/>
        </button>
      </div>

      <TabBar active={active} onSelect={onNav}/>
    </div>
  );
}

function SumRow({ l, v, hl, green }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0' }}>
      <span style={{ fontSize: 13, color: 'var(--plate-ink-2)' }}>{l}</span>
      <span className="tabular" style={{ fontSize: 13, fontWeight: 600, color: green ? 'var(--plate-leaf)' : hl ? 'var(--plate-ink)' : 'var(--plate-ink-2)' }}>{v}</span>
    </div>
  );
}

window.CheckoutScreen = CheckoutScreen;
